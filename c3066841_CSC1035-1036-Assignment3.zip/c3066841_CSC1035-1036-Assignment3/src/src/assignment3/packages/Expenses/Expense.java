package assignment3.packages.Expenses;

import assignment3.packages.Filtering.Category;
import assignment3.packages.Filtering.Currency;

import java.io.Serializable;
import java.time.LocalDate;


public record Expense(double amount, Category category, LocalDate date, Currency currency) implements Serializable {
    public double getAmount() {
        return amount;
    }
    public Currency getCurrency() {
        return currency;
    }
}
