package assignment3.packages.GUI;

import assignment3.packages.Expenses.Expense;
import assignment3.packages.Expenses.ExpensesManager;
import assignment3.packages.Expenses.SavedExpenses;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SavedExpensesPanel extends JPanel {
    private final SavedExpenses savedExpenses;
    private final JTable jsavedExpenseTable;


    public SavedExpensesPanel() {
        setLayout(new BorderLayout());

        // Initially empty and ready to be added or exported
        savedExpenses = new SavedExpenses(new ArrayList<>());
        jsavedExpenseTable = new JTable(savedExpenses);

        JScrollPane scrollPane = new JScrollPane(jsavedExpenseTable);
        add(scrollPane, BorderLayout.CENTER);
    }

    public void updateTable(List<Expense> expenses) {

        savedExpenses.setExpenses(expenses);
    }

    public List<Expense> getPreviouslySavedExpenses() {
        return ExpensesManager.getAllExpenses();
    }


    // method to select the saved expense for further manipulation
    public int getSavedSelectedExpenseIndex() {
        return jsavedExpenseTable.getSelectedRow(); // Returns -1 if no row is selected
    }
}