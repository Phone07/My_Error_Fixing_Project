package assignment3.packages.Filtering;

import assignment3.packages.Expenses.Expense;
import assignment3.packages.Expenses.ExpensesManager;
import assignment3.packages.GUI.SavedExpensesPanel;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class CategoryFilterPanel extends JPanel {
    private final ExpensesManager expensesManager;
    private final SavedExpensesPanel savedExpensesPanel;
    private final JComboBox<Category> filterComboBox;
    private final JButton filterButton;
    private final JButton restoreButton;
    private final JButton sumButton;
    private final JLabel totalAmount;

    public CategoryFilterPanel(ExpensesManager expensesManager, SavedExpensesPanel savedExpensesPanel) {
        this.expensesManager = expensesManager;
        this.savedExpensesPanel = savedExpensesPanel;

        setLayout(new FlowLayout(FlowLayout.LEFT));

        filterComboBox = new JComboBox<>(Category.values());
        add(filterComboBox);


        filterButton = new JButton("Filter");
        filterButton.addActionListener(e -> applyFilter()); // Add action listener to filter button
        add(filterButton);

        restoreButton = new JButton("Restore");
        restoreButton.addActionListener(e -> restoreFilter()); // Add action listener to restore button
        add(restoreButton);

        sumButton = new JButton("Sum");
        sumButton.addActionListener(e -> updateTotal()); //Add action listener to the sum button
        add(sumButton);

        totalAmount = new JLabel("Total Expense: 0");
        add(totalAmount);

        updateTotal(); // Call updateTotal to initialize total label
    }


    // Methods to get the selected category

    public JButton getFilterButton() {
        return filterButton;
    }

    public JButton getRestoreButton() {
        return restoreButton;
    }

    public JButton getSumButton() {
        return sumButton;
    }

    public void applyFilter() {
        Category selectedCategory = (Category) filterComboBox.getSelectedItem();
        // Retrieve filtered expenses and update the table
        savedExpensesPanel.updateTable(expensesManager.getExpensesByCategory(selectedCategory));
    }

    public boolean updateTotal() {
        List<Expense> displayedExpenses = savedExpensesPanel.getPreviouslySavedExpenses();

        if (displayedExpenses == null || displayedExpenses.isEmpty()) {
            // Display a default message and return false if the list is empty
            totalAmount.setText("Total Expense: 0");
            return true; // Indicate success
        }

        Currency firstCurrency = displayedExpenses.getFirst().getCurrency();

        for (Expense expense : displayedExpenses) {
            // Check if the currency of the current expense is different from the first one
            if (!expense.getCurrency().equals(firstCurrency)) {
                return false; // Indicate failure
            }
        }

        // Calculate the total expense and update the label
        double totalExpense = displayedExpenses.stream().mapToDouble(Expense::getAmount).sum();
        int totalExpenseInt = (int) totalExpense;
        totalAmount.setText("Total Expense: " + totalExpenseInt);

        return true; // Indicate success
    }


    public void restoreFilter() {
        List<Expense> previouslySavedExpenses = savedExpensesPanel.getPreviouslySavedExpenses();
        if (previouslySavedExpenses != null) {
            savedExpensesPanel.updateTable(previouslySavedExpenses);
        }
    }
}
