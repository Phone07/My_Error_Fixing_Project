package assignment3.packages.Filtering;

public enum Currency {
    STERLING("Sterling"),
    US_DOLLAR("Dollar"),
    EURO("Euro"),
    CHINESE_YUAN("Chinese Yuan"),
    JAPANESE_YEN("Japanese Yen");

    private final String displayName;

    Currency(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }

}
