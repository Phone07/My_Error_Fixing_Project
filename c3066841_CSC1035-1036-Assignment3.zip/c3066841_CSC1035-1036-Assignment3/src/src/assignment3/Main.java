package assignment3;

import assignment3.packages.Expenses.Expense;
import assignment3.packages.Expenses.ExpensesManager;
import assignment3.packages.Expenses.SavedExpensesEditDialog;
import assignment3.packages.Filtering.Category;
import assignment3.packages.Filtering.Currency;
import assignment3.packages.Filtering.CategoryFilterPanel;
import assignment3.packages.GUI.NewExpensesPanel;
import assignment3.packages.GUI.SavedExpensesPanel;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        createAndShowGUI();
    }

    private static void createAndShowGUI() {
        JFrame frame;
        frame = new JFrame("Expense Tracker");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Create the object of expenseManager
        ExpensesManager expensesManager = new ExpensesManager();

        // Create instances of relevant panels
        NewExpensesPanel newExpensesPanel = new NewExpensesPanel();
        SavedExpensesPanel savedExpensesPanel = new SavedExpensesPanel();
        CategoryFilterPanel categoryFilterPanel = new CategoryFilterPanel(expensesManager, savedExpensesPanel);

        // Add panels to the frame and specify their relative position in the frame
        frame.add(newExpensesPanel, BorderLayout.NORTH);
        frame.add(savedExpensesPanel, BorderLayout.CENTER);
        frame.add(categoryFilterPanel, BorderLayout.SOUTH);

        frame.pack();
        frame.setLocationRelativeTo(null); // Center the window
        frame.setVisible(true);


        // Listener for clicking save button
        newExpensesPanel.getSaveButton().addActionListener(e -> {
            double amount = newExpensesPanel.getAmount();
            if (amount != 0) {
                Category category = newExpensesPanel.getExpenseCategory();
                LocalDate date = newExpensesPanel.getDate();
                Currency currency = newExpensesPanel.getCurrency();

                Expense newExpense = new Expense(amount, category, date, currency);
                expensesManager.addExpense(newExpense);
                savedExpensesPanel.updateTable(ExpensesManager.getAllExpenses());
            } else {
                JOptionPane.showMessageDialog(frame, "Amount must be greater than zero.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        SavedExpensesEditDialog editDialog = new SavedExpensesEditDialog(frame);

        // Edit Button ActionListener
        newExpensesPanel.getEditButton().addActionListener(e -> {
            int selectedRow = savedExpensesPanel.getSavedSelectedExpenseIndex();
            if (selectedRow != -1) {
                // get the index
                Expense selectedExpense = ExpensesManager.getAllExpenses().get(selectedRow);
                boolean saved = editDialog.showDialog(selectedExpense);
                if (saved) {
                    Expense editedExpense = editDialog.getEditedExpense();
                    if (editedExpense.amount() != 0) {
                        expensesManager.replaceExpense(selectedRow, editedExpense);
                        savedExpensesPanel.updateTable(ExpensesManager.getAllExpenses());
                    } else {
                        JOptionPane.showMessageDialog(frame, "Amount must be greater than zero.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        // Delete Button ActionListener
        newExpensesPanel.getDeleteButton().addActionListener(e -> {
            int selectedRow = savedExpensesPanel.getSavedSelectedExpenseIndex();
            if (selectedRow != -1) {
                // Ensure a row is selected
                expensesManager.deleteExpense(selectedRow);
                savedExpensesPanel.updateTable(ExpensesManager.getAllExpenses());
            } else {
                JOptionPane.showMessageDialog(frame, "Please select an expense to delete.", "No Expense Selected", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Clear Button ActionListener
        newExpensesPanel.getClearButton().addActionListener(e -> {
            expensesManager.clearExpenses();
            savedExpensesPanel.updateTable(ExpensesManager.getAllExpenses());
        });


        // Filter Button ActionListener

        categoryFilterPanel.getFilterButton().addActionListener(e -> categoryFilterPanel.applyFilter());

        // Restore Button ActionListener

        categoryFilterPanel.getRestoreButton().addActionListener(e -> categoryFilterPanel.restoreFilter());

        // Sum Button ActionListener

        categoryFilterPanel.getSumButton().addActionListener(e -> {
            boolean success = categoryFilterPanel.updateTotal();
            if (!success) {
                JOptionPane.showMessageDialog(frame, "Cannot sum expenses with different currencies.", "Currency Error", JOptionPane.WARNING_MESSAGE);
            }
        });


    }
}